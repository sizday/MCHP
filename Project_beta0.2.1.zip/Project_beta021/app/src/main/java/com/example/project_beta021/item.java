package com.example.project_beta021;

public class item {
    int background;
    String profileName;


    public item(int background, String profileName){
        this.background = background;
        this.profileName = profileName;
    }

    public int getBackground() {
        return background;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setBackground(int background) {
        this.background = background;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

}
